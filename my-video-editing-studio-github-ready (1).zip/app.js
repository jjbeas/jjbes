const menuToggle = document.getElementById('menuToggle');
const mainNav = document.getElementById('mainNav');
menuToggle.addEventListener('click', () => {
  const open = mainNav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
});
mainNav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  mainNav.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
}));
document.getElementById('year').textContent = new Date().getFullYear();

document.getElementById('projectForm').addEventListener('submit', (event) => {
  event.preventDefault();
  const data = new FormData(event.currentTarget);
  const subject = encodeURIComponent('New video editing project enquiry');
  const body = encodeURIComponent(
    `Hello My Video Editing Studio,\n\nName: ${data.get('name')}\nContact: ${data.get('reply')}\nService: ${data.get('service')}\nProject details: ${data.get('details') || 'Not provided'}\n\nPlease contact me about this project.`
  );
  // Replace this address with your real business email before publishing.
  window.location.href = `mailto:jabesjack87@gmail.com?subject=${subject}&body=${body}`;
  document.getElementById('formNote').textContent = 'Your email app should open with the project details. If your email app did not open, email jabesjack87@gmail.com with your project details.';
});

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('./service-worker.js').catch(() => {}));
}
