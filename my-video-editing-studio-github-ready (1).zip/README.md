# My Video Editing Studio — website + installable app

This starter is a responsive website and a Progressive Web App (PWA). Visitors can browse services, sample portfolio layouts, package descriptions and send a project enquiry. On supported phones, they can add it to their home screen so it opens like an app.

## Preview locally
1. Unzip this folder.
2. Open `index.html` in a browser to preview the website.
3. For the installable app and offline caching, serve the folder over HTTPS or use a local development server (for example, VS Code Live Server). Service workers do not run from a normal `file://` page.

## Before publishing
- Your business email and WhatsApp contact have been added to the website and enquiry form.
- Replace the portfolio sample panels with screenshots or links to your actual videos.
- Add your real prices, turnaround times, revision policy and terms.
- The package prices are intentionally quote-based; no prices or client testimonials have been invented.

## Publish free
You can deploy the folder to a static hosting service such as GitHub Pages, Netlify or Cloudflare Pages. Use the host's instructions to publish the folder and connect your domain if you own one. A custom domain usually has a separate registration cost.

## Install on a phone
After publishing over HTTPS, open the website on your phone. On Android/Chrome use the browser menu and choose **Install app** or **Add to Home screen**. On iPhone/Safari use **Share → Add to Home Screen**.

## Important limitation
This is a website plus an installable PWA, not a native Android APK or iOS App Store app. It provides an app-like mobile experience without app-store fees. The enquiry form opens the visitor's email app; it does not upload video files or store customer orders on a server.
